
# Simple reminder app

This is a simple reminder app which is supposed to run on Android.

You can add, edit and delete tasks.
Active tasks are activating alarm in a specific time.
Alarm can be dismissed.

There are much more sophisticated reminder apps than this one, however, the purpose of this app is just to show example of development for Android.

